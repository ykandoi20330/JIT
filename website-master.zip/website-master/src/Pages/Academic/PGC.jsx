import React from 'react'

const PGC = () => {
  return (
    <div>
        PGC
    </div>
  )
}

export default PGC
