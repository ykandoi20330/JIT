import React from 'react'

const EContent = () => {
  return (
    <div>
      E-Content
    </div>
  )
}

export default EContent
