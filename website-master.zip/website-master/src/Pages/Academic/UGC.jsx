import React from 'react'

const UGC = () => {
  return (
    <div>
      UGC
    </div>
  )
}

export default UGC
