import React from 'react'

const ResearchPublications = () => {
  return (
    <div>
      Research Publications
    </div>
  )
}

export default ResearchPublications
