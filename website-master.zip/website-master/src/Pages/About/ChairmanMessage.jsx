import React from 'react'

const ChairmanMessage = () => {
  return (
    <div>
      Chairman's message
    </div>
  )
}

export default ChairmanMessage
