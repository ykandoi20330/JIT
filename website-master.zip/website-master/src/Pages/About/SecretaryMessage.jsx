import React from 'react'

const SecretaryMessage = () => {
  return (
    <div>
      Secretary message
    </div>
  )
}

export default SecretaryMessage
