import React from 'react'

const AcademicAdvisory = () => {
  return (
    <div>
      Academic advisory
    </div>
  )
}

export default AcademicAdvisory
