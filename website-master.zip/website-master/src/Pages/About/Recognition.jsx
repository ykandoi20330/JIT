import React from 'react'

const Recognition = () => {
  return (
    <div>
      Recognition
    </div>
  )
}

export default Recognition
