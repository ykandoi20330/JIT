import React from 'react'

const AboutJIT = () => {
  return (
    <div>
      About JIT
    </div>
  )
}

export default AboutJIT
