import React from 'react'

const GoverningBody = () => {
  return (
    <div>
      Governing body
    </div>
  )
}

export default GoverningBody
