import React from 'react'

const Vision = () => {
  return (
    <div>
      Vision
    </div>
  )
}

export default Vision
