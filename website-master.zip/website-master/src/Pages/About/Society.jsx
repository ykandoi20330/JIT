import React from 'react'

const Society = () => {
  return (
    <div>
      Society
    </div>
  )
}

export default Society
