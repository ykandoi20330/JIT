import React from 'react'

const WhyJIT = () => {
  return (
    <div>
      Why JIT
    </div>
  )
}

export default WhyJIT
