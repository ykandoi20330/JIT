import React from 'react'

const DirectorMessage = () => {
  return (
    <div>
      Director message
    </div>
  )
}

export default DirectorMessage
