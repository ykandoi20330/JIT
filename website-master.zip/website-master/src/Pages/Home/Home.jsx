import React from 'react'
import VideoBG from '../../assets/video.mp4'

const Home = () => {
  return (
    <div className='home h-[25vh] w-full'>
      <video src={VideoBG} autoPlay loop muted className='z-[-1] bg-cover'/>
    </div>
  )
}

export default Home
