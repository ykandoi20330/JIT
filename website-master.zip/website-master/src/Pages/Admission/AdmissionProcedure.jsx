import React from 'react'

const AdmissionProcedure = () => {
  return (
    <div>
      AdmissionProcedure
    </div>
  )
}

export default AdmissionProcedure
