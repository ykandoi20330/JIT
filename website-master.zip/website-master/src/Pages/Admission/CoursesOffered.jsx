import React from 'react'

const CoursesOffered = () => {
  return (
    <div>
      CoursesOffered
    </div>
  )
}

export default CoursesOffered
