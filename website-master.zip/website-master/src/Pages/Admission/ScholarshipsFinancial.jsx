import React from 'react'

const ScholarshipsFinancial = () => {
  return (
    <div>
      ScholarshipsFinancial
    </div>
  )
}

export default ScholarshipsFinancial
