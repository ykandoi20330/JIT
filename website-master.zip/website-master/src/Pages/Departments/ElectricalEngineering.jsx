import React from 'react'

const ElectricalEngineering = () => {
  return (
    <div>
        Electrical Engineering
    </div>
  )
}

export default ElectricalEngineering
