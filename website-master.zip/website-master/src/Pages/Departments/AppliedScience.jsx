import React from 'react'

const AppliedScience = () => {
  return (
    <div>
        Applied Science
    </div>
  )
}

export default AppliedScience
