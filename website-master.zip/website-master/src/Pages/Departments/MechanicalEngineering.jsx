import React from 'react'

const MechanicalEngineering = () => {
  return (
    <div>
      Mechanical Engineering
    </div>
  )
}

export default MechanicalEngineering
