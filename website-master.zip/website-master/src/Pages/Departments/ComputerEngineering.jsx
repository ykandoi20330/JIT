import React from 'react'

const ComputerEngineering = () => {
  return (
    <div>
        Computer Engineering
    </div>
  )
}

export default ComputerEngineering
