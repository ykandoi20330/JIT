import React from 'react'

const CivilEngineering = () => {
  return (
    <div>
        Civil Engineering
    </div>
  )
}

export default CivilEngineering
