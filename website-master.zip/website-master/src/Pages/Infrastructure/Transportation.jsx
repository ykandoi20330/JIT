import React from 'react'

const Transportation = () => {
  return (
    <div>
        Transportation
    </div>
  )
}

export default Transportation
