import React from 'react'

const Hostel = () => {
  return (
    <div>
        Hostel
    </div>
  )
}

export default Hostel
