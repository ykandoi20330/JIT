import React from 'react'

const Canteen = () => {
  return (
    <div>
        Canteen
    </div>
  )
}

export default Canteen
