import React from 'react'

const Clubs = () => {
  return (
    <div>
        Clubs
    </div>
  )
}

export default Clubs
