import React from 'react'

const TrainingAndPlacementCell = () => {
  return (
    <div>
        TrainingAndPlacementCell
    </div>
  )
}

export default TrainingAndPlacementCell
