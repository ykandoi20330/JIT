import React from 'react'

const IndustrialVisitAndTour = () => {
  return (
    <div>
        IndustrialVisitAndTour
    </div>
  )
}

export default IndustrialVisitAndTour
