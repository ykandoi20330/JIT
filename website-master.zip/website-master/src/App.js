import {Route, Routes} from 'react-router-dom';
import Home from './Pages/Home/Home';

// About imports
import AboutJIT from './Pages/About/AboutJIT';
import AcademicAdvisory from './Pages/About/AcademicAdvisory';
import ChairmanMessage from './Pages/About/ChairmanMessage';
import DirectorMessage from './Pages/About/DirectorMessage';
import GoverningBody from './Pages/About/GoverningBody';
import Recognition from './Pages/About/Recognition';
import SecretaryMessage from './Pages/About/SecretaryMessage';
import Society from './Pages/About/Society';
import Vision from './Pages/About/Vision';
import WhyJIT from './Pages/About/WhyJIT';

// Admission Imports
import AdmissionProcedure from './Pages/Admission/AdmissionProcedure';
import CoursesOffered from './Pages/Admission/CoursesOffered';
import ScholarshipsFinancial from './Pages/Admission/ScholarshipsFinancial';

// Academic Imports
import UGC from './Pages/Academic/UGC'
import PGC from './Pages/Academic/PGC'
import EContent from './Pages/Academic/EContent'
import ResearchPublications from './Pages/Academic/ResearchPublications';

// Departments Imports
import AppliedScience from './Pages/Departments/AppliedScience';
import CivilEngineering from './Pages/Departments/CivilEngineering';
import ComputerEngineering from './Pages/Departments/ComputerEngineering';
import ElectricalEngineering from './Pages/Departments/ElectricalEngineering';
import MechanicalEngineering from './Pages/Departments/MechanicalEngineering';
import ElectCommEngineering from './Pages/Departments/ElectCommEngineering';

// Infrastructure Routes
import Canteen from './Pages/Infrastructure/Canteen';
import Hostel from './Pages/Infrastructure/Hostel';
import Library from './Pages/Infrastructure/Library';
import Transportation from './Pages/Infrastructure/Transportation';

// Placement Routes
import IndustrialVisitAndTour from './Pages/Placement/IndustrialVisitAndTour';
import SummerInternship from './Pages/Placement/SummerInternship';
import TrainingAndPlacementCell from './Pages/Placement/TrainingAndPlacementCell';

// Campus Imports
import Clubs from './Pages/Campus/Clubs';
import Events from './Pages/Campus/Events';
import Sports from './Pages/Campus/Sports';
import Navbar from './Components/Navbar';

// Contact Imports
import Contact from './Pages/Contact/Contact';


function App() {
  return (
    <div className="App">
      {/* Navbar */}
      <Navbar />
      <div className="mt-16"/>
      <Routes>
        {/* Home */}
        <Route path="/" element={<Home />}/>

        {/* About Routes */}
        <Route path="/about/about-jit" element={<AboutJIT />} />
        <Route path="/about/academic-advisory" element={<AcademicAdvisory />} />
        <Route path="/about/chairman-message" element={<ChairmanMessage />} />
        <Route path="/about/director-message" element={<DirectorMessage />} />
        <Route path="/about/governing-body" element={<GoverningBody />} />
        <Route path="/about/recognition" element={<Recognition />} />
        <Route path="/about/secretary-message" element={<SecretaryMessage />} />
        <Route path="/about/society" element={<Society />} />
        <Route path="/about/vision" element={<Vision />} />
        <Route path="/about/why-jit" element={<WhyJIT />} />

        {/* Admission Routes */}
        <Route path="/admission/admission-procedure" element={<AdmissionProcedure />} />
        <Route path="/admission/courses-offered" element={<CoursesOffered />} />
        <Route path="/admission/scholarships-financial" element={<ScholarshipsFinancial />} />

        {/* Academic Routes */}
        <Route path="/academic/ugc" element={<UGC />} />
        <Route path="/academic/pgc" element={<PGC />} />
        <Route path="/academic/e-content" element={<EContent />} />
        <Route path="/academic/research-publications" element={<ResearchPublications />} />

        {/* Departments Routes */}
        <Route path="/departments/applied-science" element={<AppliedScience />} />
        <Route path="/departments/civil-engineering" element={<CivilEngineering />} />
        <Route path="/departments/computer-engineering" element={<ComputerEngineering />} />
        <Route path="/departments/electrical-engineering" element={<ElectricalEngineering />} />
        <Route path="/departments/mechanical-engineering" element={<MechanicalEngineering />} />
        <Route path="/departments/elect-comm-engineering" element={<ElectCommEngineering />} />

        {/* Infrastructure Routes */}
        <Route path="/infrastructure/canteen" element={<Canteen />} />
        <Route path="/infrastructure/hostel" element={<Hostel />} />
        <Route path="/infrastructure/library" element={<Library />} />
        <Route path="/infrastructure/transportation" element={<Transportation />} />

        {/* Placement Routes */}
        <Route path="/placement/industrial-visit-and-tour" element={<IndustrialVisitAndTour />} />
        <Route path="/placement/summer-internship" element={<SummerInternship />} />
        <Route path="/placement/training-and-placement-cell" element={<TrainingAndPlacementCell />} />

        {/* Campus Routes */}
        <Route path="/campus/clubs" element={<Clubs />} />
        <Route path="/campus/events" element={<Events />} />
        <Route path="/campus/sports" element={<Sports />} />

        {/* Contact */}
        <Route path="/contact" element={<Contact />} />
        
      </Routes>
      {/* Footer */}
    </div>
  );
}

export default App;
