import { Disclosure } from "@headlessui/react";
import { MenuIcon, XIcon } from "@heroicons/react/outline";
import DropdownNav from "../HelperComponents/DropdownNav";
import Logo from "../assets/Logo.png"
import RegularNav from "../HelperComponents/RegularNav";

const navigation = [
    {name: "HOME", routeName: '^/$', href: "/"},
    {name: "ABOUT US", routeName: "/about", dropList: [
        {href: "/about/about-jit", name: "AboutJIT"},
        {href: "/about/academic-advisory", name: "AcademicAdvisory"},
        {href: "/about/chairman-message", name: "ChairmanMessage"},
        {href: "/about/director-message", name: "DirectorMessage"},
        {href: "/about/governing-body", name: "GoverningBody"},
        {href: "/about/recognition", name: "Recognition"},
        {href: "/about/secretary-message", name: "SecretaryMessage"},
        {href: "/about/society", name: "Society"},
        {href: "/about/vision", name: "Vision"},
        {href: "/about/why-jit", name: "WhyJIT"},
    ]},
    {name: "ADMISSION", routeName: "^/admission/*", dropList: [
        {href: "/admission/admission-procedure", name: "AdmissionProcedure"},
        {href: "/admission/courses-offered", name: "CoursesOffered"},
        {href: "/admission/scholarships-financial", name: "ScholarshipsFinancial"},
    ]},
    {name: "ACADEMIC", routeName: "^/academic/*", dropList: [
        { href: "/academic/ugc", name:"UGC" },
        { href: "/academic/pgc", name:"PGC" },
        { href: "/academic/e-content", name:"EContent" },
        { href: "/academic/research-publications", name:"ResearchPublications" },
    ]},
    {name: "DEPARTMENTS", routeName: "^/departments/*", dropList: [
        {href: "/departments/applied-science", name: "AppliedScience"},
        {href: "/departments/civil-engineering", name: "CivilEngineering"},
        {href: "/departments/computer-engineering", name: "ComputerEngineering"},
        {href: "/departments/electrical-engineering", name: "ElectricalEngineering"},
        {href: "/departments/mechanical-engineering", name: "MechanicalEngineering"},
        {href: "/departments/elect-comm-engineering", name: "ElectCommEngineering"},
    ]},
    {name: "INFRASTRUCTURE", routeName: "^/infrastructure/*", dropList: [
        {href: "/infrastructure/canteen", name: "Canteen"},
        {href: "/infrastructure/hostel", name: "Hostel"},
        {href: "/infrastructure/library", name: "Library"},
        {href: "/infrastructure/transportation", name: "Transportation"},
    ]},
    {name: "PLACEMENT & TRAINING", routeName: "^/placement/*", dropList: [
        {href: "/placement/industrial-visit-and-tour", name: "IndustrialVisitAndTour"},
        {href: "/placement/summer-internship", name: "SummerInternship"},
        {href: "/placement/training-and-placement-cell", name: "TrainingAndPlacementCell"},
    ]},
    {name: "CAMPUS LIFE", routeName: "^/campus/*", dropList: [
        {href: "/campus/clubs", name: "Clubs"},
        {href: "/campus/events", name: "Events"},
        {href: "/campus/sports", name: "Sports"},
    ]},
    {name: "CONTACT US", routeName: "^/contact/*", href: '/contact'},
];

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export default function Navbar() {
  const navBarThickness = "5px";
  return (
    <Disclosure as="nav" className={`bg-gray-800 fixed top-0 z-10 w-full ${navBarThickness}`}>
      {({ open }) => (
        <>
          <div className="max-w-[100%] mx-auto px-2 sm:px-6 lg:px-8">
            <div className="relative flex items-center justify-between h-16">
              <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
                {/* Mobile menu button*/}
                <Disclosure.Button className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                  <span className="sr-only">Open main menu</span>
                  {open ? (
                    <XIcon className="block h-6 w-6" aria-hidden="true" />
                  ) : (
                    <MenuIcon className="block h-6 w-6" aria-hidden="true" />
                  )}
                </Disclosure.Button>
              </div>
              <div className="flex-1 flex items-center justify-center sm:items-stretch sm:justify-start">
                <div className="flex-shrink-0 flex items-center">
                  <img className="h-8 w-auto" src={Logo} alt="JIT Logo" />
                </div>
                <div className="hidden sm:block sm:ml-6">
                  <div className="flex space-x-4">
                    {navigation.map((item) => (
                      item.dropList? <DropdownNav item={item} key={item.name} /> : <RegularNav item={item} key={item.name} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Disclosure.Panel className="sm:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigation.map((item) => (
                <Disclosure.Button
                  key={item.name}
                  as="a"
                  href={item.href}
                  className={classNames(
                    item.current
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white",
                    "block px-3 py-2 rounded-md text-base font-medium"
                  )}
                  aria-current={item.current ? "page" : undefined}
                >
                  {item.name}
                </Disclosure.Button>
              ))}
            </div>
          </Disclosure.Panel>
        </>
      )}
    </Disclosure>
  );
}