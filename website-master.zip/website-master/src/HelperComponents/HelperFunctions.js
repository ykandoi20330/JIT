exports.classNames = function(...args) {
    return args.filter(Boolean).join(' ');
}