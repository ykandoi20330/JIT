import React from 'react'
import { Link, useLocation } from 'react-router-dom';
import { classNames } from './HelperFunctions';


const RegularNav = (props) => {
    const { item } = props;
    const location = useLocation()
    const current = location.pathname.match(RegExp(item.routeName));
    
  return (
    <div>
        <div className="bg-gray-800 flex text-sm rounded-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white">
            <Link
              key={item?.name}
              to={item.href}
              className={classNames(
                current
                  ? "bg-gray-900 text-white"
                  : "text-gray-300 hover:bg-gray-700 hover:text-white",
                "px-3 py-2 rounded-md text-sm font-medium"
              )}
              aria-current={item?.current ? "page" : undefined}
            >
              {item?.name}
            </Link>
            
          </div>
    </div>
  )
}

export default RegularNav
